from django.urls import path
from . import views
urlpatterns = [
    path('', views.diretorio_home, name='diretorio_home'),
]
