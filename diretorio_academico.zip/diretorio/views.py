from django.shortcuts import render
def diretorio_home(request):
    return render(request, 'diretorio.html')
