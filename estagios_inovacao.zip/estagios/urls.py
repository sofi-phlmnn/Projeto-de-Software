from django.urls import path
from . import views
urlpatterns = [
    path('', views.estagios_home, name='estagios_home'),
]
