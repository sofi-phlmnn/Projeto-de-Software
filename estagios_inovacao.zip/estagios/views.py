from django.shortcuts import render
def estagios_home(request):
    return render(request, 'estagios.html')
