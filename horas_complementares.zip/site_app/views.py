from django.shortcuts import render
def horas_complementares(request):
    return render(request, 'horas_complementares.html')
