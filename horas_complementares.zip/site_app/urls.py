from django.urls import path
from . import views
urlpatterns = [path('', views.horas_complementares, name='horas_complementares'),]
